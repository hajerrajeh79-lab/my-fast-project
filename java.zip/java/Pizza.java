public class Pizza implements Product {
    private final String name;
    private double price;

    public Pizza(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public Pizza(String name) {
        this.name = name;
    }

    @Override
    public String getName() { return name; }

    @Override
    public double getPrice() { return price; }

    @Override
    public void displayInfo() {
        System.out.println("Pizza: " + name + " - Price: " + price + " USD");
    }
}