import java.util.ArrayList;
import java.util.List;

/**
 * Order class - holds items and status, and notifies observers via OrderSubject
 */
public class Order {

    private final String id;                     // ثابت ولا يتغير
    private final List<Product> items = new ArrayList<>();
    private String status;
    private final OrderSubject subject;

    public Order(String id, OrderSubject subject) {
        this.id = id;
        this.subject = subject;
        this.status = "Created";
  }
{
  System.out.println("Status changed to: " + status);
}
    public String getId() {
        return id;
    }

    public void addItem(Product p) {
        items.add(p);
    }

    public double total() {
        double sum = 0;
        for (Product p : items) {
            sum += p.getPrice();
        }
        return sum;
    }

    public void setStatus(String status) {
        this.status = status;
        subject.notifyObservers(this, status);
    }

    public String getStatus() {
        return status;
    }

    public List<Product> getItems() {
        return items;
    }
}