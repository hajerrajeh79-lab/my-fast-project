public class WarehouseManager implements OrderObserver {
    private final  String name;
    public WarehouseManager(String name) { this.name = name; }

    @Override
    public void update(Order order, String status) {
        System.out.println("WarehouseManager " + name + " notified: Order " + order.getId() + " status -> " + status);
    }
}