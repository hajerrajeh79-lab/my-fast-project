import java.util.ArrayList;
import java.util.List;

public class OrderSubject {

    private  final List<OrderObserver> observers = new ArrayList<>();

    public void addObserver(OrderObserver o) {
        observers.add(o);
    }

    public void removeObserver(OrderObserver o) {
        observers.remove(o);
    }

    public void notifyObservers(Order order, String status) {
        for (OrderObserver o : observers) {
            o.update(order, status);
        }
    }
}