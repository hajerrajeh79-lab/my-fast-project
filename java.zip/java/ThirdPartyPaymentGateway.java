/**
 * Simulated third-party payment gateway with different API
 */
public class ThirdPartyPaymentGateway {
    public String processPayment(double amount, String currency) {
        System.out.println("Processing via ThirdPartyGateway: " + amount + " " + currency);
        // Simulate success
        return "TXN" + System.currentTimeMillis();
    }
}