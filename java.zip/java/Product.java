public interface Product {
    String getName();
    double getPrice();
    void displayInfo();
}