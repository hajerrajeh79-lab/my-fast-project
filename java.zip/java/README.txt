README - Online Ordering System
-------------------------------
وصف المشروع:
نظام مصغّر لإدارة طلبات الأونلاين يوضّح تطبيق أنماط التصميم: Factory, Adapter, Observer.

ملفات المشروع:
- src/*.java  (كل ملفات الجافا)
- Report.pdf
- Slides.pdf

طريقة التشغيل:
1. افتح Terminal داخل src
2. javac *.java
3. java Main

نماذج المستخدم:
- Creational: ProductFactory
- Structural: PaymentAdapter
- Behavioral: OrderSubject + OrderObserver