
public class PaymentAdapter implements PaymentProcessor {
    private  final ThirdPartyPaymentGateway gateway;

    public PaymentAdapter(ThirdPartyPaymentGateway gateway) {
        this.gateway = gateway;
    }

    @Override
    public boolean pay(double amount) {
        String txn = gateway.processPayment(amount, "USD");
        return txn != null && !txn.isEmpty();
    }
}