public interface PaymentProcessor {
    boolean pay(double amount);
}