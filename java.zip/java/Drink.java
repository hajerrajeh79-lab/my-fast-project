public class Drink implements Product {
    private final String name;
    private double price;

    public Drink(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public Drink(java.lang.String name) {
        this.name = name;
    }

    @Override
    public String getName() { return name; }

    @Override
    public double getPrice() { return price; }

    @Override
    public void displayInfo() {
        System.out.println("Drink: " + name + " - Price: " + price + " USD");
    }
}