public class Main {
    public static void main(String[] args) {
        // Setup observers and subject
        OrderSubject subject = new OrderSubject();
        Customer customer = new Customer("Ali");
        WarehouseManager wm = new WarehouseManager("Store1");
        subject.addObserver(customer);
        subject.addObserver(wm);

        // Create order and items using Factory
        Order order = new Order("ORD001", subject);
        order.addItem(ProductFactory.createProduct("pizza", "Margherita", 8.5));
        order.addItem(ProductFactory.createProduct("drink", "Cola", 1.5));

        System.out.println("Total: " + order.total());

        // Pay using Adapter
        ThirdPartyPaymentGateway gateway = new ThirdPartyPaymentGateway();
        PaymentProcessor processor = new PaymentAdapter(gateway);
        boolean paid = processor.pay(order.total());

        if (paid) {
            order.setStatus("Confirmed");
            // simulate shipping
            order.setStatus("Shipped");
            order.setStatus("Delivered");
        } else {
            order.setStatus("Payment Failed");
        }
    }
}