public class Customer implements OrderObserver {
    private final  String name;
    public Customer(String name) { this.name = name; }

    @Override
    public void update(Order order, String status) {
        System.out.println("Customer " + name + " notified: Order " + order.getId() + " is " + status);
    }
}