public class ProductFactory {
    public static Product createProduct(String type, String name, double price) {
        if (type.equalsIgnoreCase("pizza")) {
            return new Pizza(name, price);
        } else if (type.equalsIgnoreCase("drink")) {
            return new Drink(name, price);
        } else {
            throw new IllegalArgumentException("Unknown product type: " + type);
        }
    }
}